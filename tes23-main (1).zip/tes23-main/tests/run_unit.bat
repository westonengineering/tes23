@echo off
rem run_unit.bat - builds and runs the unit tests. They are written against the
rem invented demo ICD in tests\demo, so they keep working whatever the real ICD
rem in icd\project.json contains. Output goes to bin\demo.
setlocal
cd /d "%~dp0.."
set ROOT=%CD%

set VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe
for /f "usebackq delims=" %%i in (`"%VSWHERE%" -latest -products * -requires Microsoft.Component.MSBuild -find MSBuild\**\Bin\MSBuild.exe`) do set MSBUILD=%%i
if not defined MSBUILD (echo MSBuild was not found & exit /b 1)
set COMMON=-m -v:quiet -nologo -p:Configuration=Release -p:Platform=x64
set DEMO="-p:IcdGeneratedDir=%ROOT%\tests\demo\generated" "-p:OutDir=%ROOT%\bin\demo\\"

echo === Generating demo ICD
python tools\icdgen.py tests\demo\project_demo.json --out tests\demo\generated > tests\demo\generator_report.txt || exit /b 1

echo === Building
"%MSBUILD%" native\IcdLink.vcxproj %COMMON% %DEMO% "-p:IntDir=%ROOT%\obj\demo\IcdLink\\" || exit /b 1
"%MSBUILD%" native\IcdLinkCli.vcxproj %COMMON% %DEMO% "-p:IntDir=%ROOT%\obj\demo\IcdLinkCli\\" || exit /b 1
"%MSBUILD%" native\IcdLinkTests.vcxproj %COMMON% %DEMO% "-p:IntDir=%ROOT%\obj\demo\IcdLinkTests\\" || exit /b 1
"%MSBUILD%" csharp\IcdLink.Tests\IcdLink.Tests.csproj -restore %COMMON% || exit /b 1

set FAILED=0
echo.
echo === Engine tests
bin\demo\IcdLinkTests.exe || set FAILED=1
echo.
echo === C# runtime tests
bin\demo\tests\net48\IcdLink.Tests.exe || set FAILED=1
echo.
echo === Batch file example
call tests\demo_test.bat || set FAILED=1

echo.
if %FAILED%==0 (echo ALL PASSED) else (echo FAILED)
exit /b %FAILED%
