#!/usr/bin/env python
"""Checks raw frames dumped by IcdMatrixTests, with no project code involved.

The dump starts with '#crc ...' and '#channel X start=N' lines giving the framing.
Each other line is: name txLen rxLen sameLayout <tx frame hex> <rx frame hex>
Frames are as on the wire without the optional 0xFF: [start byte] ID payload CRC-32.
sameLayout is 0 when the send and receive ICDs differ, so only length and CRC apply.
Usage: check_wire.py dump.txt
"""
from __future__ import print_function
import binascii
import sys


def reflect(value, bits):
    out = 0
    for i in range(bits):
        if value & (1 << i):
            out |= 1 << (bits - 1 - i)
    return out


def crc32(data, p):
    """Bit-by-bit CRC-32, written from the definition rather than from a table."""
    crc = p["init"]
    for byte in bytearray(data):
        if p["refin"]:
            byte = reflect(byte, 8)
        crc ^= byte << 24
        for _ in range(8):
            crc = ((crc << 1) ^ p["poly"]) & 0xFFFFFFFF if crc & 0x80000000 else (crc << 1) & 0xFFFFFFFF
    if p["refout"]:
        crc = reflect(crc, 32)
    return crc ^ p["xorout"]


def crc_ok(frame, head, p):
    skip = head + 1 if not p["covers_type"] else (0 if p["covers_start"] else head)
    body, wire = frame[:-4], bytearray(frame[-4:])
    got = 0
    for i in range(4):
        got |= wire[3 - i if p["big"] else i] << (8 * i)
    return got == crc32(body[skip:], p)


def main():
    checked = failed = 0
    params, starts = None, {}
    with open(sys.argv[1]) as handle:
        for line in handle:
            if line.startswith("#crc"):
                params = dict((k, int(v, 0)) for k, v in (x.split("=") for x in line.split()[1:]))
                continue
            if line.startswith("#channel"):
                _, ch, start = line.split()
                starts[ch] = int(start.split("=")[1])
                continue
            if params is None:
                print("FAIL: dump has no #crc line")
                return 1
            name, tx_len, rx_len, same_layout, tx_hex, rx_hex = line.split()
            tx_len, rx_len = int(tx_len), int(rx_len)
            tx, rx = bytearray(binascii.unhexlify(tx_hex)), bytearray(binascii.unhexlify(rx_hex))
            start = starts.get(name[0], -1)
            head = 1 if start >= 0 else 0
            problems = []
            if len(tx) != head + tx_len + 4:
                problems.append("tx is %d bytes on the wire" % len(tx))
            if len(rx) != head + rx_len + 4:
                problems.append("rx is %d bytes on the wire" % len(rx))
            if head and (tx[:1] != bytearray([start]) or rx[:1] != bytearray([start])):
                problems.append("start byte is not 0x%02X" % start)
            if not crc_ok(tx, head, params):
                problems.append("tx CRC wrong")
            if not crc_ok(rx, head, params):
                problems.append("rx CRC wrong")
            if same_layout == "1" and rx[head:head + rx_len] != tx[head:head + rx_len]:
                problems.append("rx is not the start of tx")
            checked += 1
            if problems:
                failed += 1
                print("FAIL %s: %s" % (name, ", ".join(problems)))
    print("%d frame pairs checked independently, %d failed" % (checked, failed))
    return 1 if failed or not checked else 0


if __name__ == "__main__":
    sys.exit(main())
