#!/usr/bin/env python
"""Works out the CRC settings from a frame the device really sent.

Copy a frame from the test GUI's "raw RX" line (or a logic analyser) and run:

    python tools\\crc_find.py 90 10 05 12 34 00 00 A1 B2 C3 D4 FF

Every CRC-32 variant with polynomial 0x04C11DB7 is tried: bit reflection on or
off, init 0 or FFFFFFFF, final XOR 0 or FFFFFFFF, CRC sent MSB or LSB first, and
CRC computed over start+ID+payload, ID+payload or payload only. A trailing 0xFF
is ignored. The matching "crc" block for icd\\project.json is printed.

    python tools\\crc_find.py --check

prints the CRC of the ASCII text 123456789 for the common variants, to compare
with the value the FPGA or firmware team gets from the same nine bytes.

Plain Python 2.7 or 3.5+, no imports beyond the standard library.
"""
from __future__ import print_function
import sys

POLY = 0x04C11DB7

# name, reflect, init, xorout  (the usual catalogue names for these parameter sets)
VARIANTS = [
    ("CRC-32 (zlib, Ethernet, ISO-HDLC)", True, 0xFFFFFFFF, 0xFFFFFFFF),
    ("CRC-32/BZIP2 (MSB first, ISO 3309 init and final XOR)", False, 0xFFFFFFFF, 0xFFFFFFFF),
    ("CRC-32/MPEG-2 (MSB first, no final XOR)", False, 0xFFFFFFFF, 0x00000000),
    ("CRC-32/POSIX (MSB first, init 0)", False, 0x00000000, 0xFFFFFFFF),
    ("CRC-32/JAMCRC (zlib without final XOR)", True, 0xFFFFFFFF, 0x00000000),
    ("MSB first, init 0, no final XOR", False, 0x00000000, 0x00000000),
    ("reflected, init 0, final XOR", True, 0x00000000, 0xFFFFFFFF),
    ("reflected, init 0, no final XOR", True, 0x00000000, 0x00000000),
]


def reflect(value, bits):
    out = 0
    for i in range(bits):
        if value & (1 << i):
            out |= 1 << (bits - 1 - i)
    return out


def table():
    """The MSB-first table: entry 1 is the polynomial, 0x04C11DB7."""
    t = []
    for i in range(256):
        c = i << 24
        for _ in range(8):
            c = ((c << 1) ^ POLY) & 0xFFFFFFFF if c & 0x80000000 else (c << 1) & 0xFFFFFFFF
        t.append(c)
    return t


TABLE = table()


def crc32(data, refl, init, xorout):
    c = init
    for b in bytearray(data):
        if refl:
            b = reflect(b, 8)
        c = ((c << 8) & 0xFFFFFFFF) ^ TABLE[((c >> 24) ^ b) & 0xFF]
    if refl:
        c = reflect(c, 32)
    return c ^ xorout


def parse_hex(args):
    text = " ".join(args).replace(",", " ").replace(":", " ").replace("-", " ")
    out = []
    for token in text.split():
        if token.lower().startswith("0x"):
            token = token[2:]
        if len(token) % 2:
            token = "0" + token
        for i in range(0, len(token), 2):
            out.append(int(token[i:i + 2], 16))
    return bytearray(out)


def check():
    data = bytearray(b"123456789")
    print("CRC of the ASCII bytes 31 32 33 34 35 36 37 38 39 ('123456789'):")
    for name, refl, init, xorout in VARIANTS:
        print("  0x%08X  %s" % (crc32(data, refl, init, xorout), name))
    print("")
    print("Table check: entry[1] = 0x%08X, entry[128] = 0x%08X (MSB-first table)" % (TABLE[1], TABLE[128]))
    print("A reflected (zlib) table instead has entry[1] = 0x77073096, entry[128] = 0xEDB88320.")


def find(frame):
    trimmed = [frame]
    if len(frame) > 5 and frame[-1] == 0xFF:
        trimmed.insert(0, frame[:-1])
    hits = []
    for f in trimmed:
        if len(f) < 5:
            continue
        body, tail = f[:-4], f[-4:]
        for big in (True, False):
            wire = 0
            for i in range(4):
                wire |= tail[3 - i if big else i] << (8 * i)
            for skip, what in ((0, "everything before the CRC"), (1, "all but the first byte"),
                               (2, "all but the first two bytes")):
                if skip >= len(body):
                    continue
                for name, refl, init, xorout in VARIANTS:
                    if crc32(body[skip:], refl, init, xorout) == wire:
                        hits.append((f is not frame, big, skip, what, name, refl, init, xorout))
    if not hits:
        print("No CRC-32 variant with polynomial 0x04C11DB7 matches this frame.")
        print("Check the bytes are one whole frame, from the start byte to the last CRC byte.")
        return 1
    for had_ff, big, skip, what, name, refl, init, xorout in hits:
        print("MATCH: %s" % name)
        print("  CRC over %s, sent %s first%s" % (what, "MSB" if big else "LSB", ", then 0xFF" if had_ff else ""))
        if skip == 2:
            covers = '"covers_type": false'
        elif skip == 1:
            covers = '"covers_type": true, "covers_start": false'
        else:
            covers = '"covers_type": true, "covers_start": true'
        print('  "crc": { "poly": "0x04C11DB7", "init": "0x%08X", "xorout": "0x%08X",' % (init, xorout))
        print('           "reflect_in": %s, "reflect_out": %s, "byte_order": "%s", %s }' % (
            "true" if refl else "false", "true" if refl else "false", "big" if big else "little", covers))
        print("")
    print("With a start byte: 'everything' = start+ID+payload, 'all but the first byte' = ID+payload,")
    print("'all but the first two bytes' = payload only.")
    return 0


def main(argv):
    if len(argv) < 2 or argv[1] in ("-h", "--help"):
        print(__doc__)
        return 2
    if argv[1] == "--check":
        check()
        return 0
    try:
        frame = parse_hex(argv[1:])
    except ValueError:
        print("Give the frame as hex bytes, e.g. 90 10 05 12 34 A1 B2 C3 D4 FF")
        return 2
    return find(frame)


if __name__ == "__main__":
    sys.exit(main(sys.argv))
